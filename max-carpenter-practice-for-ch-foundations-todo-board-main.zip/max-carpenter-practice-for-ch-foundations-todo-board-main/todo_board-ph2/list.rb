require_relative "item"

class List
    attr_accessor :label
    def initialize(label)
        @label = label
        @items = []
    end
    def add_item(title, deadline, description = "")
        if Item.valid_date?(deadline)
            @items << Item.new(title, deadline, description)
            return true
        else
            return false
        end
    end
    def size
        @items.length
    end
    def valid_index?(index)
        return false if index < 0
        return index < size
    end
    def swap(index_1, index_2)
        if !valid_index?(index_1) || !valid_index?(index_2)
            return false
        else
            @items[index_1], @items[index_2] = @items[index_2], @items[index_1]
            return true
        end
    end
    def [](index)
        return nil if !valid_index?(index)
        @items[index]
    end
    def priority
        @items[0]
    end
    def print
        puts "-------------------------------------------------"
        puts self.label.upcase.center(49)
        puts "-------------------------------------------------"
        puts "Done " + " | " + "Index".ljust(5) + " | " + "Item".ljust(20) + " | " + "Deadline"
        puts "-------------------------------------------------"
        @items.each_with_index do |item,i|
            puts item.done.to_s.ljust(5) + " | " + i.to_s.ljust(5) + " | " + item.title.ljust(20) + " | " + item.deadline
        end
        puts "-------------------------------------------------"
    end
    def print_full_item(index)
        if self.valid_index?(index)
            puts "------------------------------------------"
            puts self[index].title.ljust(32) + self[index].deadline
            puts self[index].description
            puts "Done?: " + self[index].done.to_s
            puts "------------------------------------------"
            return true
        else
            return false
        end
    end
    def print_priority
        self.print_full_item(0)
    end
    def down(index, amount = 1)
        if !self.valid_index?(index)
            return false
        else
            amount.times do
                if index != self.size - 1
                    @items[index], @items[index+1] = @items[index+1], @items[index] 
                    index += 1
                end
            end
            return true
        end
    end
    def up(index, amount=1)
        if !self.valid_index?(index)
            return false
        else
            amount.times do
                if index != 0
                    @items[index], @items[index-1] = @items[index-1], @items[index] 
                    index -= 1
                end
            end
            return true
        end
    end
    def sort_by_date!
        @items.sort_by! {|item| item.deadline}
    end
    def toggle_item(index)
        @items[index].toggle
    end
    def remove_item(index)
        return false if !self.valid_index?(index)
        @items.delete_at(index)
        return true
    end
    def purge
        @items.reject! {|item| item.done}
        return true
    end
end