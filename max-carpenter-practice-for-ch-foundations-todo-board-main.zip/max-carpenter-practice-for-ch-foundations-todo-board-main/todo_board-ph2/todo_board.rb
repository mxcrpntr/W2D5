require_relative "item"
require_relative "list"

class TodoBoard
    def initialize
        @lists = Hash.new(0)
    end
    def get_command
        print "\nEnter a command: "
        cmd, *args = gets.chomp.split(" ")
        case cmd
        when "mklist"
            @lists[*args] = List.new(*args)
            return true
        when "ls"
            @lists.each_key {|k| puts k}
            return true
        when "showall"
            @lists.each_value {|v| v.print}
            return true
        when "mktodo"
            list = args.shift
            @lists[list].add_item(*args)
            return true
        when "up"
            list = args.shift
            args[0] = args[0].to_i
            args[1] = args[1].to_i if args.length > 1
            @lists[list].up(*args)
            return true
        when "down"
            list = args.shift
            args[0] = args[0].to_i
            args[1] = args[1].to_i if args.length > 1
            @lists[list].down(*args)
            return true
        when "swap"
            list = args.shift
            args[0] = args[0].to_i
            args[1] = args[1].to_i
            @lists[list].swap(*args)
            return true
        when "sort"
            @lists[*args].sort_by_date!
            return true
        when "priority"
            @lists[*args].print_priority
            return true
        when "print"
            list = args.shift
            if args.length == 0
                @lists[list].print
            else
                args[0] = args[0].to_i
                @lists[list].print_full_item(*args)
            end
            return true
        when "toggle"
            list = args.shift
            args[0] = args[0].to_i
            @lists[list].toggle_item(*args)
            return true
        when "rm"
            list = args.shift
            args[0] = args[0].to_i
            @lists[list].remove_item(*args)
            return true
        when "purge"
            @lists[*args].purge
            return true
        when "quit"
            return false
        else
            print "Sorry, that command is not recognized."
            return true
        end
    end
    def run
        while true
            if !self.get_command
                return
            end
        end
    end
end

todo = TodoBoard.new
todo.run