require_relative "item"
class Item
    attr_reader :deadline, :done
    attr_accessor :title, :description
    def initialize(title, deadline, description)
        @title = title
        if !Item.valid_date?(deadline)
            raise "Given deadline is not a valid date of the form 'YYYY-MM-DD'."
        else
            @deadline = deadline
        end
        @description = description
        @done = false
    end
    def self.valid_date?(date_string)
        words = date_string.split("-")
        if words.length != 3 || words[0].length != 4 || words[1].length != 2 || words[2].length != 2
            return false
        end
        y = words[0].to_i
        m = words[1].to_i
        d = words[2].to_i
        return false if !(1..12).to_a.include?(m) || !(1..31).to_a.include?(d)
        true
    end
    def deadline=(new_deadline)
        if !Item.valid_date?(new_deadline)
            raise "Given deadline is not a valid date of the form 'YYYY-MM-DD'."
        else
            @deadline = new_deadline
        end
    end
    def toggle
        @done = !@done
    end
end