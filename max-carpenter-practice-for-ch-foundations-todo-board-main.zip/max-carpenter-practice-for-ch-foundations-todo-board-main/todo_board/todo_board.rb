require_relative "item"
require_relative "list"

class TodoBoard
    def initialize(label)
        @list = List.new(label)
    end
    def get_command
        print "\nEnter a command: "
        cmd, *args = gets.chomp.split(" ")
        case cmd
        when "mktodo"
            @list.add_item(*args)
            return true
        when "up"
            args[0] = args[0].to_i
            args[1] = args[1].to_i if args.length > 1
            @list.up(*args)
            return true
        when "down"
            args[0] = args[0].to_i
            args[1] = args[1].to_i if args.length > 1
            @list.down(*args)
            return true
        when "swap"
            args[0] = args[0].to_i
            args[1] = args[1].to_i
            @list.swap(*args)
            return true
        when "sort"
            @list.sort_by_date!
            return true
        when "priority"
            @list.print_priority
            return true
        when "print"
            if args.length == 0
                @list.print
            else
                args[0] = args[0].to_i
                @list.print_full_item(*args)
            end
            return true
        when "quit"
            return false
        else
            print "Sorry, that command is not recognized."
        end
    end
    def run
        while true
            if !self.get_command
                return
            end
        end
    end
end